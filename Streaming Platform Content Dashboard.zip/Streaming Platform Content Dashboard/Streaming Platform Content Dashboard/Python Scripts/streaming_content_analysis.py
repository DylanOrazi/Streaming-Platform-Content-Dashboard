import pandas as pd
from datetime import datetime
import os


dataset_path = "../dataset/streaming_content_dataset.xlsx"

df = pd.read_excel(dataset_path, sheet_name="Content_Data")

print("Dataset loaded successfully.")
print(df.head())
print(df.info())
print(df.describe())


print("\nColumn Names:")
print(df.columns)

print("\nMissing Values:")
print(df.isnull().sum())

print("\nDuplicate Rows:")
print(df.describe())

df = df.drop_duplicates()


current_year = datetime.now().year

df["score_gap"] = df["audience_score"] - df["critic_score"]
df["absolute_score_gap"] = df["score_gap"].abs()

df["content_age"] = current_year - df["release_year"]

df["release_decade"] = (df["release_year"] // 10 * 10).astype(str) + "s"

df["views_per_watch_hour"] =df["monthly_views_millions"] / df["watch_hours_millions"]

df["performance_category"] = pd.cut(
    df["popularity_score"],
    bins=[0, 40, 70, 100],
    labels=["Low Performance", "Average Performance", "High Performance"]
)

df["runtime_category"] =pd.cut(
    df["runtime_minutes"],
    bins=[0, 45, 90, 130, 300],
    labels=["Short", "Medium", "Long", "Very Long"]
)

df["completion_category"] =pd.cut(
    df["completion_rate"],
    bins=[0, 60, 80, 100],
    labels=["Low Completion", "Average Completion", "High Completion"]
) 


summary_by_platform = df.groupby("platform").agg(
    total_titles=("content_id", "count"),
    avg_audience_score=("audience_score", "mean"),
    avg_critic_score=("critic_score", "mean"),
    avg_popularity_score=("popularity_score", "mean"),
    total_monthly_views=("monthly_views_millions", "sum"),
    total_watch_hours=("watch_hours_millions", "sum"),
    avg_completion_rate=("completion_rate", "mean")
).reset_index()

summary_by_genre = df.groupby("genre").agg(
    total_titles=("content_id", "count"),
    avg_audience_score=("audience_score", "mean"),
    avg_critic_score=("critic_score", "mean"),
    avg_popularity_score=("popularity_score", "mean"),
    total_monthly_views=("monthly_views_millions", "sum"),
    total_watch_hours=("watch_hours_millions", "sum"),
    avg_completion_rate=("completion_rate", "mean")
).reset_index()

summary_by_content_type = df.groupby("content_type").agg(
    total_titles=("content_id", "count"),
    avg_audience_score=("audience_score", "mean"), 
    avg_popularity_score=("popularity_score", "mean"),
    total_watch_hours=("watch_hours_millions", "sum"),
).reset_index()

summary_by_decade = df.groupby("release_decade").agg(
    total_titles=("content_id", "count"),
    avg_audience_score=("audience_score", "mean"),
    avg_popularity_score=("popularity_score", "mean"),
).reset_index()

top_10_watch_hours = df.sort_values(
    by="watch_hours_millions",
    ascending=False
).head(10)

top_10_popularity = df.sort_values(
    by="popularity_score",
    ascending=False
).head(10)


numeric_cols = [
    "audience_score",
    "critic_score",
    "monthly_views_millions",
    "watch_hours_millions",
    "completion_rate",
    "score_gap",
    "absolute_score_gap",
    "views_per_watch_hour"
]

df[numeric_cols] = df[numeric_cols].round(2)

for table in [
    summary_by_platform,
    summary_by_genre,
    summary_by_content_type,
    summary_by_decade
]:
    numeric_table_cols = table.select_dtypes(include="number").columns
    table[numeric_table_cols] = table[numeric_table_cols].round(2)


exports_folder = "../Exports"

if not os.path.exists(exports_folder):
    os.makedirs(exports_folder)

df.to_csv(f"{exports_folder}/streaming_content_cleaned.csv", index=False)
summary_by_platform.to_csv(f"{exports_folder}/summary_by_platform.csv", index=False)
summary_by_genre.to_csv(f"{exports_folder}/summary_by_genre.csv", index=False)
summary_by_content_type.to_csv(f"{exports_folder}/summary_by_content_type.csv", index=False)
summary_by_decade.to_csv(f"{exports_folder}/summary_by_decade.csv", index=False)
top_10_watch_hours.to_csv(f"{exports_folder}/top_10_watch_hours.csv", index=False)
top_10_popularity.to_csv(f"{exports_folder}/top_10_popularity.csv", index=False)

print("\nExport completed successfully.")
print("Files saved to the Exports folder.") 
























    
